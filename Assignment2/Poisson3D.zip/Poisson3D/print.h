#ifndef _PRINT_H
#define _PRINT_H

void print_binary(char *fname, int num, double ***u);

void print_vtk(const char *fname, int n, double ***u);

#endif
