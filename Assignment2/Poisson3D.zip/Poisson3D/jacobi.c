/* jacobi.c - Poisson problem in 3d
 * 
 */
#include <math.h>

void
jacobi() {
    // fill in your code here
}
